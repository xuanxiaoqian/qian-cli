import{_ as s,c as n,o as a,a as p}from"./app.d08fa4e7.js";const d=JSON.parse('{"title":"\u76EE\u5F55\u7ED3\u6784","description":"","frontmatter":{},"headers":[],"relativePath":"configDoc/baseConfig/baseDir.md"}'),l={name:"configDoc/baseConfig/baseDir.md"},e=p(`<h1 id="\u76EE\u5F55\u7ED3\u6784" tabindex="-1">\u76EE\u5F55\u7ED3\u6784 <a class="header-anchor" href="#\u76EE\u5F55\u7ED3\u6784" aria-hidden="true">#</a></h1><div class="language-d"><button class="copy"></button><span class="lang">d</span><pre><code><span class="line"><span style="color:#A6ACCD;">.</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 </span><span style="color:#F78C6C;">public</span><span style="color:#A6ACCD;"> #\u516C\u5171\u6587\u4EF6</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2514\u2500\u2500 vite.svg #\u7F51\u7AD9\u56FE\u6807</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 src  #\u5F00\u53D1\u76EE\u5F55</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 assets #\u8D44\u6E90\u6587\u4EF6</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502   \u251C\u2500\u2500 images #\u56FE\u7247\u8D44\u6E90</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502   \u2514\u2500\u2500 style #\u6837\u5F0F\u8D44\u6E90</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502       \u2514\u2500\u2500 reset.css #\u9875\u9762\u91CD\u7F6E</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 components #\u7EC4\u4EF6</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 hooks </span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502   \u2514\u2500\u2500 usePoint.ts</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 layout #\u5168\u5C40\u5E03\u5C40\u6587\u4EF6</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 router #\u8DEF\u7531</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502   \u2514\u2500\u2500 modules #\u8DEF\u7531\u6A21\u5757</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502       \u251C\u2500\u2500 home.ts #\u4E3B\u9875</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502       \u2514\u2500\u2500 pathMatch.ts #\u901A\u914D\u7B26\u5339\u914D\u4E0D\u5B58\u5728\u7684\u8DEF\u7531</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2502   \u251C\u2500\u2500 index.ts #\u7EDF\u4E00\u8DEF\u7531</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 utils #\u5DE5\u5177\u6587\u4EF6\u5939</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2514\u2500\u2500 views #\u9875\u9762\u6587\u4EF6\u5939</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502       \u251C\u2500\u2500 </span><span style="color:#F78C6C;">404.</span><span style="color:#A6ACCD;">vue</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502       \u2514\u2500\u2500 Home.vue</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 types #typescript\u7C7B\u578B\u63D0\u793A</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 </span><span style="color:#C792EA;">auto</span><span style="color:#89DDFF;">-import</span><span style="color:#A6ACCD;">.d.ts #\u81EA\u52A8\u5BFC\u5165</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 </span><span style="color:#89DDFF;">import-</span><span style="color:#A6ACCD;">meta.d.ts #\u73AF\u5883\u53D8\u91CF</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u2514\u2500\u2500 vite</span><span style="color:#89DDFF;">-</span><span style="color:#A6ACCD;">env.d.ts #vite</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 App.vue</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2502   \u251C\u2500\u2500 main.ts</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 .env.development #\u5F00\u53D1\u73AF\u5883\u53D8\u91CF</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 .env.production #\u751F\u6210\u73AF\u5883\u53D8\u91CF</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 index.html</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 </span><span style="color:#F78C6C;">package</span><span style="color:#89DDFF;">-</span><span style="color:#A6ACCD;">lock.json</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 </span><span style="color:#F78C6C;">package</span><span style="color:#A6ACCD;">.json</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 README.md</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 tsconfig.json</span></span>
<span class="line"><span style="color:#A6ACCD;">\u251C\u2500\u2500 tsconfig.node.json</span></span>
<span class="line"><span style="color:#A6ACCD;">\u2514\u2500\u2500 vite.config.ts</span></span>
<span class="line"></span>
<span class="line"></span></code></pre></div>`,2),o=[e];function c(t,C,A,r,i,D){return a(),n("div",null,o)}const _=s(l,[["render",c]]);export{d as __pageData,_ as default};
